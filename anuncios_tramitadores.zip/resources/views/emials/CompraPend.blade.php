@component('mail::message')


![logo](http://metalbit.co/core/img/AzulMetalicoHor.png)

Estimad@ {{$user->name}}, Hemos registrado una compra Pendiente falta que la confirmes.



## Resumen Oferta ##
Anuncio:
Estado: PENDIENTE







Gracias, por seguir confiando en nosotros<br>
{{ config('app.name') }}
@endcomponent
