@component('mail::message')


![logo](http://metalbit.co/core/img/AzulMetalicoHor.png)

Estimad(@) {{$user->name}}, hemos registrado una compra falta que la confirmes.



## Resumen Oferta ##
Anuncio:
Estado: PENDIENTE









Gracias, por seguir confiando en nosotros<br>
{{ config('app.name') }}
@endcomponent

