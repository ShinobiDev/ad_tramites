@extends('layouts.master')
@section('content')

      <section class="pages container">
          <div class="page page-about">
                <h1 class="text-capitalize">Pagína no Encontrada</h1> <hr>
                <p>Volver a <a href="{{route('home')}}">Inicio</a></p>
          </div>
      </section>

@endsection
