
@foreach($tramites as $t)
<div class="col-md-4 label-col form-group">
    <input id="ch_{{$t->id}}" type="checkbox" name="tramites" value="{{$t->id}}">
    <label name="lbl_tramite" id="lbl_{{$t->id}}" class="label-col">{{$t->nombre_tramite}}</label>
    <input id="tra_{{$t->id}}" style="display: none;" class="textinput textInput form-control"  name="valor" type="text" placeholder="Valor del servicio"/>
</div>
@endforeach
