@extends('layouts.app')
@section('head')

@endsection
@section('header')
    <h1>
        Anuncios vistos por mi
    </h1>
    <small>Listado</small>

    <ol class="breadcrumb">
      <li><a href="{{route('welcome')}}"><i class="fa fa-dashboard">Inicio</i></a></li>
      <li class="active"></li>
    </0l>

@endsection

@section('content')

  <div class="container">
    <div class="box box-primary">
      <div class="box-header">
          <h3 class="box-title">Listado de anuncios</h3>
            
            

      </div>
      <div class="box-body">
                <table id="vistos-table"class="table table-striped table-codensed table-hover table-resposive">
                      <thead>
                        <tr>
                          <th>Tipo transacción</th>
                          <th>Descripcion</th>
                          <th>Ciudad</th>
                          <th>Calificación</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                     
                      <tbody>
                        {{--se crean las tablas de ventas--}} 
                        @foreach ($anuncios as $ad)
                            
                             <tr>
                              <td class="text-green text-center"><strong><h3>Tramite</h3></strong></td>
                              <td class=" text-center"><strong><h5>{{$ad->descripcion}}</h5></strong></td>
                              <td class=" text-center"><strong><h5>{{$ad->ciudad}}</h5></strong></td>
                              <td>
                                @for($i=1;$i<=$ad->calificacion;$i++)
                                  @if($i<=5)
                                    <img  class="star" src="{{asset('img/star.png')}}">
                                    @endif
                                @endfor
                              </td>
                             <td>
                              
                                @guest
                                       <!--AQUI SE MUESTRA LOS BOTONES PARA LOGIN -->

                                        <button id="{{'btn_'.$ad->cod_anuncio}}" type="button" class="btn btn-success" data-toggle="modal" onclick="descontar_recargar('{{ 'ventana_login'.$ad->id}}','{{$ad->cod_anuncio}}','0','info')">
                                          Ver info
                                          </button>
                                                                
                                        <button id="{{'btn_'.$ad->cod_anuncio}}" type="button" class="btn btn-default" data-toggle="modal" onclick="descontar_recargar('{{ 'ventana_login'.$ad->id}}','{{$ad->cod_anuncio}}','0','venta')">
                                          Comprar
                                        </button>
                                       
                                    
                                    @include('anuncios.ventana_modal_login')  
                                @else
                                  
                                   
                                    
                                      @if($ad->btn_info) 
                                        @if($ad->visto!="") 
                                       
                                          <a href="anuncios_vistos" class="btn btn-primary">Ya lo Viste</a>
                                                              
                                          
                                        @else
                                          <button id="{{'btn_'.$ad->cod_anuncio}}" type="button" class="btn btn-success" data-toggle="modal" onclick="descontar_recargar('{{ 'infogen'.$ad->id}}','{{$ad->id}}','{{$ad->costo_clic}}','info')">
                                          Ver info
                                          </button>
                                                              
                                          @include('anuncios.ventana_modal_info_general')


                                        @endif
                                        
                                      @endif                                

                                      @if($ad->btn_payu)  
                                        <button id="{{'btn_'.$ad->cod_anuncio}}" type="button" class="btn btn-default" data-toggle="modal" onclick="descontar_recargar('{{ 'infoventa'.$ad->id}}','{{$ad->id}}','0','compra')" >
                                          Comprar
                                        </button>
                                      
                                       @include('anuncios.ventana_modal_info_anuncio')
                                      @endif
                                    
                                    

                                @endguest
                                  
                                  
                              </td>
                             </tr>
                           
                        @endforeach
                        {{--/se crean las tablas de ventas--}} 
                      </tbody>
                </table>
      </div>
      
        
 
    </div>
  </div>


@endsection



@section('scripts')
    
          <script type="text/javascript">
           
                  $(function (){
                      $('#vistos-table').DataTable({
                        'language':
                          {
                            "sProcessing":     "Procesando...",
                            "sLengthMenu":     "Mostrar _MENU_ registros",
                            "sZeroRecords":    "No se encontraron resultados",
                            "sEmptyTable":     "Ningún dato disponible en esta tabla",
                            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                            "sInfoPostFix":    "",
                            "sSearch":         "Buscar:",
                            "sUrl":            "",
                            "sInfoThousands":  ",",
                            "sLoadingRecords": "Cargando...",
                            "oPaginate": {
                                "sFirst":    "Primero",
                                "sLast":     "Último",
                                "sNext":     "Siguiente",
                                "sPrevious": "Anterior"
                            },
                            "oAria": {
                                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                            }
                        }
                      });
                  });
            
  
             </script>
@endsection


@include('partials.scripts')
