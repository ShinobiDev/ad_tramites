
@foreach($ad->tramites as $d)

	<div class="modal-body">
          <h6><b>{{$d->nombre_tramite}}</b> $ {{number_format($d->valor_tramite,2)}}  </h6>
     	</div>
	            
@endforeach  