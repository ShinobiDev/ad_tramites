<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/clearcache', function(){
      Artisan::call('cache:clear');
      Artisan::call('config:clear');
      Artisan::call('route:clear');
      Artisan::call('view:clear');
      // Artisan::call('event:generate ');
      // Artisan::call('key:generate');
      return '<h1>se ha borrado el cache</h1>';
  });



Auth::routes();	
Route::get('/','AnuncioController@index' )->name('anuncios.index');
Route::group(["prefix"=>"admin","middleware"=>"auth"],function(){
	Route::get('/home', 'AnunciosController@index')->name('welcome');
  Route::resource('anuncios', 'AnuncioController');	
	Route::resource('users', 'UsersController');
	Route::resource('permissions', 'PermissionsController');	
	Route::resource('roles', 'RolesController');
	Route::get("anuncios_vistos","UsersController@anuncios_vistos_por_mi");
  Route::get('descontar_recargas/{id_anuncio}/{costo}/{id_user}/{tipo}','UsersController@registro_consulta_ad');
	Route::get("mis_bonificaciones","UsersController@mis_bonificaciones");	
});
