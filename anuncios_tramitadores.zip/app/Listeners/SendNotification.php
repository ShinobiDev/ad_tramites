<?php

namespace App\Listeners;

use App\Events\Notificaciones;
use Illuminate\Support\Facades\Mail;
Use App\Mail\NotificationMail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;




class SendNotification
{
  
    /**
     * Handle the event.
     *
     * @param  UserWasCreated  $event
     * @return void
     */
    public function handle(Notificaciones $event)
    {   
        $url = "";
        
            if(Auth()->user()!=null){
                $url.=config('app.url')."user/".trim($event->user->id);
            }else{
                $url.=config('app.url')."login/";

            }
        //dd($url);    
        Mail::to($event->user->email)->queue(
          //dd($event)  
          new NotificationMail($event->user, $event->ad,$event->recarga,$event->tipo,$url)
        );



    }
}
