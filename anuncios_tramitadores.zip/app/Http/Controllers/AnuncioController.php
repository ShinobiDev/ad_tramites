<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Anuncio;
use App\User;
use App\Tramite;
use DB;

class AnuncioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   


        $u=auth()->user();
        //dd($u);
        $anuncios_consultados=array();

        if($u!=null){
            //dd($u->id);
            $uc=User::where('id','<>',auth()->user()->id)->get();
            $arr=[];
            $i=0;
            //dd($uc);
            foreach ($uc as $key => $value) {
                //dd($value->id);
                $arr[$i++]=$value->id;
            }
        }else{

            $uc=User::all();

            $arr=[];
            $i=0;
            foreach ($uc as $key => $value) {
                
                    $arr[$i++]=$value->id;
                

            }
        }


        //dd($arr);
        if(count($arr)>0){
           $anuncios_consultados= Anuncio::select('anuncios.id',
                                                   'anuncios.codigo_anuncio',
                                                   'anuncios.descripcion_anuncio',
                                                   'anuncios.estado_anuncio',
                                                   'anuncios.id_user',
                                                   'anuncios.ciudad',
                                                   'users.nombre',
                                                   'users.email',
                                                   'users.telefono',
                                                   'users.valor_recarga',
                                                   'users.costo_clic',
                                                   DB::Raw("FORMAT(users.nota/users.num_calificaciones,1) as calificacion"))
                ->join('users','users.id','anuncios.id_user')
                ->whereIn('users.id',$arr)
                ->get();
           //dd($anuncios_consultados);
           $ad_arr=new Anuncio();
           $arr_anuncios = $ad_arr->ver_anuncios($anuncios_consultados);
          //dd($arr_anuncios);
           return view('welcome')->with('anuncios',$arr_anuncios)->with("mis_anuncios",false);
        } 
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        
      



         
      return view('anuncios.create')->with("tramites",Tramite::all());
         
           
      
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //dd($request->get('data'));
        $dt=$request->get('data');
        $ad_c=Anuncio::insertGetId(["codigo_anuncio"=>"t".time(),
                          "descripcion_anuncio"=>$dt["descripcion"],
                          "id_user"=>auth()->user()->id,
                          "ciudad"=>$dt["ubicacion"]['ciudad']
                        ]);
        //dd($dt['tramites']);
        $ad=new Anuncio();
        foreach ($dt['tramites'] as $key => $value) {
            //var_dump($value);
            $ad->asociar_tramites($ad_c,$value,$dt["valores"][$key]);
        }
        //
        return response()->json(["respuesta"=>true,"mensaje"=>"Anuncio creado"]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $ad=new Anuncio();
        $a= Anuncio::select('anuncios.id',
                                                   'anuncios.codigo_anuncio',
                                                   'anuncios.descripcion_anuncio',
                                                   'anuncios.estado_anuncio',
                                                   'anuncios.id_user',
                                                   'anuncios.ciudad',
                                                   'users.nombre',
                                                   'users.email',
                                                   'users.telefono',
                                                   'users.valor_recarga',
                                                   'users.costo_clic',
                                                   'users.nota',
                                                    DB::Raw("FORMAT(users.nota/users.num_calificaciones,1) as calificacion"))
                ->join('users','users.id','anuncios.id_user')
                ->where('users.id',auth()->user()->id)
                ->get();
            
        $arr_anuncios=$ad->ver_anuncios($a);
        //dd($arr_anuncios);
        return view('welcome')->with('anuncios',$arr_anuncios)->with("mis_anuncios",true);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
