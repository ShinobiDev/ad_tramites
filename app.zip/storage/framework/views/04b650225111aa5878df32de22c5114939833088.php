<div>
  <input   name="merchantId"    type="hidden"   value="<?php echo e(trim($ad->merchantId)); ?>"   >
  <input name="accountId"     type="hidden"   value="<?php echo e(trim($ad->accountId)); ?>" >
  <input id="hd_description_<?php echo e($ad->id); ?>" name="description"   type="hidden"   value="<?php echo e(trim($ad->descripcion)); ?>"  >
  <input name="referenceCode" type="hidden"   value="<?php echo e($ad->cod_anuncio); ?>" >

  
    <input id="hd_valor_venta_<?php echo e($ad->id); ?>" name="amount"        type="hidden"   value="<?php echo e($ad->valor_tramite); ?>" >
    <input id="currency_<?php echo e($ad->id); ?>" name="currency"     type="hidden"   value="COP" >
  
  
  <input name="tax"           type="hidden"   value="0"  >
  <input name="taxReturnBase" type="hidden"   value="0" >
  <input id="hd_signature_<?php echo e($ad->id); ?>" name="signature"     type="hidden"   value="<?php echo e(trim($ad->hash)); ?>"  >
  <input name="buyerEmail"    type="hidden"   value="<?php echo e(trim(Auth::user()->email)); ?>" >
  <input name="responseUrl"    type="hidden"   value="<?php echo e(config('app.url').trim($ad->resp)); ?>" >
  <input name="confirmationUrl"    type="hidden"   value="<?php echo e(config('app.url').trim($ad->conf)); ?>" >
  <input id="btn_comprar_<?php echo e($ad->id); ?>" type="submit" name="submit" value="COMPRAR" class="btn btn-success">
</div>
                                                                