<div class="modal fade" id="<?php echo e('infogen'.$ad->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="overflow-y: scroll;">
    <div class="modal-dialog" role="document" >
      <div class="modal-content">

        <div class="modal-header bg-primary">
          <h3 style="text-align: center;" class="modal-title" id="exampleModalLabel"><b>Información de tu Tramitador</b></h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="salir_modal('<?php echo e('infogen'.$ad->id); ?>')">
            <span aria-hidden="true" >&times;</span>
          </button>
        </div>
        <?php if($ad->validez_anuncio=="0"): ?>
          <div class="modal-body">
            <b class="text-red">Este anuncio se encuentra bloqueado y no lo podra ver la comunidad, por favor comunicate con el administrador de <?php echo e(config('app.name')); ?> para hacer la respectiva verificación y activación</b>
          </div>
        <?php endif; ?>
        <div class="modal-body">
          <b>Nombre del ofertante:</b> <?php echo e($ad->nombre); ?>

        </div>
         <div class="modal-body">
          <b>Teléfono del ofertante:</b> <?php echo e($ad->telefono); ?>

        </div>
         <div class="modal-body">
          <b>Correo del ofertante:</b> <?php echo e($ad->correo_ofertante); ?>

        </div>
        <div class="modal-body">
          <b>Horario de atención:  </b> Desde <?php echo e(explode("|",$ad->horarios->horario)[0]); ?> hasta  <?php echo e(explode("|",$ad->horarios->horario)[1]); ?>

          
        </div>
        <div class="modal-body">
          <b>Ciudad:</b>
          <?php echo e($ad->ciudad); ?>

          <br>
        </div>
        <div class="modal-body">
          <b>Descripción:</b>
          <p><?php echo e($ad->descripcion); ?></p>
        </div>
        <div class="modal-body">
            <b>Trámite: </b>
            <h6><b><?php echo e($ad->nombre_tramite); ?></b> $ <?php echo e(number_format($ad->valor_tramite,0)); ?>  </h6>
        </div>
        <div class="modal-body">
            <h4>Calificación del anunciante: </h4>
            <?php for($i=1;$i<=$ad->calificacion;$i++): ?>
              <?php if($i<=5): ?>
                <img  class="star" src="<?php echo e(asset('img/star.png')); ?>">
                <?php endif; ?>
            <?php endfor; ?>
         </div>
         <div class="modal-body">
          <h6>Visto por última vez <?php echo e($ad->visto); ?></h6>
        </div>
        <div class="modal-body" >
          <h4>Comentarios de otros usuarios: </h4>
          <?php echo $__env->make('partials.comentarios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="salir_modal('<?php echo e('infogen'.$ad->id); ?>')">SEGUIR VIENDO ANUNCIOS</button>
        </div>
      </div>
    </div>
</div>
