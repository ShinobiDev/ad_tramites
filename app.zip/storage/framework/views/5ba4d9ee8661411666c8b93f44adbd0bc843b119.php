<?php for($i=1;$i<=$ad->calificacion;$i++): ?>
  <?php if($i<=5): ?>
    <img  class="star" style="margin-left: 5px" src="<?php echo e(asset('img/star.png')); ?>">
    <?php endif; ?>
<?php endfor; ?>
