<!--anuncios-->
 

<div class="container-fluid">
 <div class="col-md-12 col-lg-offset-0">
    <div class="box box-primary">
      <div class="box-header">
          <h3 class="box-title">Encuentra tu Tramitador</h3>
            <?php if(auth()->guard()->guest()): ?>
              <div class="d-flex">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary pull-right btn-lg" >
                  <i class="fa fa-user-plus"> Crear Anuncio</i>
                </a>
                 <a href="<?php echo e(config('app.url')); ?>" class="btn btn-success pull-right btn-lg" >
                    <i class="fa "> Ver más anuncios</i>
                 </a>
                 <a href="/" class="btn btn-default pull-right btn-lg" >
                    <i class="fa "> Reiniciar busqueda</i>
                 </a>  
              </div>
              
              <?php else: ?> 
               <div class="d-flex">
                <a href="<?php echo e(route('anuncios.create')); ?>" class="btn btn-primary pull-right btn-lg" >
                    <i class="fa fa-user-plus"> Crear Anuncio</i>
                </a>
                
                <a href="<?php echo e(config('app.url')); ?>" class="btn btn-success pull-right btn-lg" >
                    <i class="fa "> Ver más anuncios</i>
                </a>
                
                <a href="/" class="btn btn-default pull-right btn-lg" >
                    <i class="fa "> Reiniciar busqueda</i>
                </a>
              </div>  
              <?php endif; ?> 

      </div>
      <div class="box-body"> 
         
      
              <?php echo $__env->make('partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo $__env->make('anuncios.tabla_anuncios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>              
      
      </div>



    </div>


 </div>
</div>
<!--anuncios-->


  