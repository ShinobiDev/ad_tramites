 <div class="modal fade" id="<?php echo e('ventana_login'.$ad->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">

        <div class="modal-header bg-primary">
          <h5 class="modal-title text-center" id="exampleModalLabel">Ingresa tus datos. Debes estar Registrado. Registrarse es Gratis.</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="salir_modal('<?php echo e('ventana_login'.$ad->id); ?>')">
            <span aria-hidden="true" >&times;</span>
          </button>
        </div>

        <div class="modal-body">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email" class="col-md-4 control-label">E-Mail </label>

                    <div class="col-md-6">
                        <input id="email<?php echo e($ad->id); ?>" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" onchange="agregar_correo(this,'<?php echo e($ad->id); ?>')" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="col-md-4 control-label">Clave</label>
                    <div class="col-md-6">
                        <input id="password<?php echo e($ad->id); ?>" type="password" class="form-control" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <div class="checkbox">
                            <button type="submit" class="btn btn-primary">
                                Ingresar
                            </button>
                            <a id="an_email_enviar_<?php echo e($ad->id); ?>" href="<?php echo e(route('register').'/?'); ?>e=<?php echo e(old('email')); ?>" class="btn btn-primary">Registrarse</a>
                            
                        </div>

                    </div>

                </div>
            </form>
            <!--FORMULARIO PARA ENVIAR EMAIL-->
            <div class="modal-body">
                <div class="form-group col-md-6 col-md-offset-4">

                        
                            
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Recordarme
                            </label>

                            <a id="anOlvide<?php echo e($ad->id); ?>" class="btn btn-link" href="<?php echo e(route('password.request').'/?'); ?>e=<?php echo e(old('email')); ?>">
                              Olvide mi clave
                            </a>
                       

                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="salir_modal('<?php echo e('ventana_login'.$ad->id); ?>')">SALIR</button>
        </div>
      </div>
    </div>
</div>
<script type="text/javascript">
    function agregar_correo(e,id){
        document.getElementById('anOlvide'+id).href="<?php echo e(route('password.request')); ?>?e="+document.getElementById(e.id).value;        
        document.getElementById('an_email_enviar_'+id).href="<?php echo e(route('register')); ?>?e="+document.getElementById(e.id).value;
    }    
</script>

