<?php if(empty($errors)==false): ?>
  <?php if(asset($errors) && count($errors) >0): ?>
    <div class="alert alert-danger alert-dismissible fade in" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li> <strong> <?php echo $error; ?></strong> </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  <?php endif; ?>

<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>

      <strong><?php echo session()->get('error'); ?></strong>
    </div>


<?php endif; ?>

<?php if(empty($no_tiene)==false ): ?>
   <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>

      <strong><?php echo e($no_tiene); ?></strong>
    </div>
<?php endif; ?>
