<!--DEBE IR AL FINAL-->    
<script type="text/javascript">
        
    var dz=new Dropzone('.dropzone',{
        url:"/",
        //url:"<?php echo e(config('app.url')); ?>"+"/subir_archivo",
        dictDefaultMessage:"Sube tus archivos aquí",
        maxFiles:1,
        maxFilesize:10,//MB
        acceptedFiles: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel",
        dictMaxFilesExceeded:"Solo esta permitido subir un archivo",
        dictInvalidFileType:"Este tipo de archivos no esta permitido",
        headers:{
          'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'
        }    

    });
    dz.on('error',function(file,rs){
        console.log(rs.errors.file[0]);
        var msg=rs.errors.file[0];

        document.querySelector(".dz-error-message > span").innerHTML=msg; 
    });
    Dropzone.autoDiscover=false;   
  
</script>