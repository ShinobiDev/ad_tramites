<?php $__env->startComponent('mail::message'); ?>


![logo](http://tutramitador.com/core/img/logo.png)

Estimad@ <?php echo e($user->nombre); ?>, la siguiente es información importante para realizar tu trámite

##VENDEDOR##

# Nombre: 
<?php echo e($ad[0]->nombre); ?>

# Télefono:
 <?php echo e($ad[0]->telefono); ?>

# Correo electrónico:
 <?php echo e($ad[0]->email); ?>


## Resumen Oferta ##

Anuncio:

# Trámite 
 <?php echo e($ad[1]->nombre_tramite); ?>

# Ciudad 
 <?php echo e($ad[1]->ciudad); ?> 
## Mensaje de tu tramitador ##
<?php echo e($ad[3]['mensaje']); ?>




#[Ver compra y enviar documentación][1]
[1]:<?php echo e($ad[2]['url']); ?>



Gracias, por seguir confiando en nosotros<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>