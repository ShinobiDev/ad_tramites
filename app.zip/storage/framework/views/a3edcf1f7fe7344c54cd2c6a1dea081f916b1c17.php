<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <h1>
        Mis ventas
    </h1>
    <small>Listado</small>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('welcome')); ?>"><i class="fa fa-dashboard">Inicio</i></a></li>
      <li class="active">Ingresos</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <div class="container">
    <div class="box box-primary">
      <div class="box-header">
          <h3 class="box-title">Listado de ventas realizadas</h3>
      </div>
      <div class="box-body">
          <table id="ventas-table" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Tipo</th>    
                <th>Trámite</th>      
                <th>ventador</th>
                <th>Estado venta</th>
                <th>Valor vendido</th>
                <th>Referecia de pago</th>
                <th>Fecha transacción</th>
                <th>Calificación</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $mis_ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>                   
                    <td>venta</td>   
                    <td><?php echo e($venta->nombre_tramite); ?></td>   
                    <td><?php echo e($venta->nombre); ?></td>
                    <td>
                      <?php if($venta->estado_pago=="PENDIENTE"): ?>
                        PENDIENTE POR PAGO
                      <?php elseif($venta->estado_pago=="APROBADA"): ?>
                        PAGO ACEPTADO
                      <?php elseif($venta->estado_pago=="DOCUMENTACION SOLICITADA"): ?>  
                        DOCUMENTACIÓN SOLICITADA
                      <?php elseif($venta->estado_pago=="DOCUMENTACION RECIBIDA"): ?>  
                        DOCUMENTACIÓN RECIBIDA
                      <?php elseif($venta->estado_pago=="TRAMITE REALIZADO"): ?>  
                        TRÁMITE REALIZADO
                      <?php elseif($venta->estado_pago=="TRANSACCION FINALIZADA"): ?>  
                        TRANSACCIÓN FINALIZADA
                      <?php elseif($venta->estado_pago=="RECHAZADA"): ?>  
                         VENTA RECHAZADA
                      <?php endif; ?>
                    </td>
                  
                    <td><?php echo e(number_format($venta->transation_value,0,',','.')); ?></td>                                    
                    <td><?php echo e($venta->transactionId); ?></td>                                   
                    <td><?php echo e($venta->updated_at); ?></td>
                    <td> <?php for($i=1;$i<=$venta->calificacion;$i++): ?>
                          <?php if($i<=5): ?>
                            <img  class="star" src="<?php echo e(asset('img/star.png')); ?>">
                          <?php endif; ?>
                        <?php endfor; ?>
                    </td> 
                    <td>
                      <?php if($venta->estado_pago=="APROBADA"): ?>
                        <button id="<?php echo e('btn_cal_'.$venta->id_pago); ?>" type="button" class="btn btn-primary" data-toggle="modal" onclick="descontar_recargar('<?php echo e('ventana_notificar_comprador'.$venta->id_pago); ?>','<?php echo e($venta->id_pago); ?>','0',false)" >
                                                  Solicitar documentos
                        </button>
                        <?php echo $__env->make('partials.notificar_comprador',['ad'=>$venta], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      <?php elseif($venta->estado_pago=="DOCUMENTACION SOLICITADA"): ?>  
                        <button id="<?php echo e('btn_cal_'.$venta->id_pago); ?>" type="button" class="btn btn-primary" data-toggle="modal" onclick="descontar_recargar('<?php echo e('ventana_notificar_comprador'.$venta->id_pago); ?>','<?php echo e($venta->id_pago); ?>','0',false)" >
                                                    Solicitar documentos de nuevo
                        </button>
                        <?php echo $__env->make('partials.notificar_comprador',['ad'=>$venta], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      <?php elseif($venta->estado_pago=="DOCUMENTACION RECIBIDA"): ?>  
                        <button id="<?php echo e('btn_cal_'.$venta->id_pago); ?>" type="button" class="btn btn-success" data-toggle="modal" onclick="descontar_recargar('<?php echo e('descargar_documentos'.$venta->id_pago); ?>','<?php echo e($venta->id_pago); ?>','0',false)" >
                                                    Descargar documentos
                        </button>
                        <?php echo $__env->make('partials.descargar_documentos',['ad'=>$venta,'archivos'=>$archivos[$venta->id_pago]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!--notificar transaccion finalizada-->
                        <button id="<?php echo e('btn_cal_'.$venta->id_pago); ?>" type="button" class="btn btn-warning" data-toggle="modal" onclick="descontar_recargar('<?php echo e('descargar_documentos'.$venta->id_pago); ?>','<?php echo e($venta->id_pago); ?>','0',false)" >
                                                    Notificar al cliente
                        </button>
                        <?php echo $__env->make('partials.descargar_documentos',['ad'=>$venta], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      <?php elseif($venta->estado_pago=="TRAMITE REALIZADO"): ?>  
                        TRÁMITE REALIZADO
                      <?php endif; ?>
                    </td>       
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

          <script>
              $(document).ready(function() {
              $('#ventas-table').DataTable( {
                  dom: 'Bfrtip',
                  buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                  language:
                    {
                      "sProcessing":     "Procesando...",
                      "sLengthMenu":     "Mostrar _MENU_ registros",
                      "sZeroRecords":    "No se encontraron resultados",
                      "sEmptyTable":     "Ningún dato disponible en esta tabla",
                      "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                      "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                      "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                      "sInfoPostFix":    "",
                      "sSearch":         "Buscar:",
                      "sUrl":            "",
                      "sInfoThousands":  ",",
                      "sLoadingRecords": "Cargando...",
                      "oPaginate": {
                          "sFirst":    "Primero",
                          "sLast":     "Último",
                          "sNext":     "Siguiente",
                          "sPrevious": "Anterior"
                      },
                      "oAria": {
                          "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                          "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                      }
                  }
              } );
              filtro_url('#ventas-table');

            });
          </script>
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
  function cambiar_valor_clic(id){
     peticion_ajax("get","cambiar_valor_clic/"+id+"/"+document.getElementById("rec_"+id).value,function(rs){
        console.log(rs);
     });
  }
</script>

<script type="text/javascript">
  function ver_bonificaciones(id){
     peticion_ajax("get","ver_bonificaciones_mis_bonificaciones/"+id,function(rs){
        console.log(rs);
        var ls=document.getElementById("tbl_mis_lista");
        ls.innerHTML="";
        for(var f in rs.datos){
          var tr=document.createElement("tr");
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].id;
          tr.appendChild(td);

          
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].nombre;
          tr.appendChild(td);

          
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].valor_bonificacion;
          tr.appendChild(td);

          
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].estado_detalle_bonificacion;
          tr.appendChild(td);

          
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].referencia_pago;
          tr.appendChild(td);

          
          var td=document.createElement("td");
          td.innerHTML=rs.datos[f].created_at;
          tr.appendChild(td);
          ls.appendChild(tr);  
        }

     });
  }

</script>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>