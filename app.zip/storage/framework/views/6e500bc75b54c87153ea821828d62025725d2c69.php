  <!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?></title>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin-lte/plugins/datatables/datatables.min.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <!-- Styles -->
  <style>
      html, body {
          font-family: arial;
      }

  </style>
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon.ico')); ?>">  
  <!--<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dropzone.css')); ?>">
  <script type="text/javascript" src="<?php echo e(asset('js/dropzone.js')); ?>"></script> -->
  
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.css">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.js"></script>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">

                        <img class="logo" src="<?php echo e(asset('img/logo.png')); ?>">
                        
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">

                       <?php if(auth()->guard()->guest()): ?>
                        <!-- <li>
                           <a href="<?php echo e(route('login')); ?>">Vender</a>
                        </li>
                        <li>
                           <a href="<?php echo e(route('login')); ?>">Comprar</a>
                        </li>-->
                        <input type="hidden" value="{0" id="user_id">
                      <?php else: ?>
                        
                        <li>
                           <a href="<?php echo e(route('anuncios.create')); ?>">Publicar anuncios</a>
                        </li>
                        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                        <li>
                           <a href="<?php echo e(route('anuncios.show',['id'=>Auth::user()->id])); ?>">Todos los anuncios</a>
                        </li>
                        <li>
                          <a href="<?php echo e(route('recargas.show')); ?>"> Estadistica recargas</a>
                        </li> 
                        <li>
                          <a href="<?php echo e(route('users.show', auth()->user())); ?>">Recargar</a>
                        </li> 
                        <?php endif; ?>
                        <?php if(auth()->check() && auth()->user()->hasRole('Anunciante')): ?>
                          <li>
                             <a href="<?php echo e(route('anuncios.show',['id'=>Auth::user()->id])); ?>">Mis anuncios</a>
                          </li>
                          <li>
                            <a href="<?php echo e(route('mis_ventas', auth()->user())); ?>">Mis ventas</a>
                          </li>
                          <li>
                            <a href="<?php echo e(route('mis_compras', auth()->user())); ?>">Mis compras</a>
                          </li>
                           <li>
                            <a href="<?php echo e(route('users.show', auth()->user())); ?>">Recargar</a>
                          </li>
                        <?php endif; ?>
                        <?php if(auth()->check() && auth()->user()->hasRole('Usuario')): ?>
                          <li>
                            <a href="<?php echo e(route('mis_compras', auth()->user())); ?>">Mis compras</a>
                          </li>                          
                        <?php endif; ?>
                      <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" id="user_id">
                      <?php endif; ?>
                      <li>
                       
                      </li>

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->


                             <li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Ingresar</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Registrarse</a></li>
                            <li><a href="/ayuda">Ayuda</a></li>
                        <?php else: ?>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
                                    <?php echo e(Auth::user()->nombre); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu">



                                      <li class="dropdown">
                                        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?> 
                                         <a href="<?php echo e(route('users.index')); ?>">Usuarios</a>
                                         <a href="<?php echo e(route('permissions.index')); ?>">Permisos</a>
                                         <a href="<?php echo e(route('roles.index')); ?>">Roles</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('users.show', auth()->user())); ?>">Perfil</a>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <strong>Salir</strong>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                      </li>



                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->make('partials.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <footer class="">
        <div class="container">
          <center style="height:50px;">
              <a href="http://prismaweb.co/diseno-a-la-medida/" target="_blank" >Desarollado por: </a>
              <a href="http://prismaweb.co/diseno-a-la-medida/" target="_blank" ><img src="http://metalbit.co/core/img/PrimaGris.png" alt="WWW.PRISMAWEB.CO - Skype: prismaweb22" /></a>
          <center/>
        </div>
    </footer>

    <!-- Scripts -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/notas.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/recargas.js')); ?>"></script>

    
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/jquery.dataTables.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/dataTables.buttons.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/buttons.flash.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/jszip.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/pdfmake.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/vfs_fonts.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/buttons.html5.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datatables/buttons.print.min.js')); ?>">  </script>
    <script src="<?php echo e(asset('admin-lte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>

    

    <?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
