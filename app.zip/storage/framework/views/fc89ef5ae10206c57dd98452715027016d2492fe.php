<?php $__env->startComponent('mail::message'); ?>


![logo](<?php echo e(config('app.url')); ?>/img/logo.png)

Estimad@ <?php echo e($user->nombre); ?>, han visto tu anuncio en  <?php echo e(config('app.name')); ?>


## Usuario que ha visto tu anuncio ##

## Nombre : <?php echo e($ad[1]->nombre); ?>

## Teléfono: <?php echo e($ad[1]->telefono); ?>

## Email: <?php echo e($ad[1]->email); ?>


## Resumen Oferta ##

Anuncio:

# Trámite
 <?php echo e($ad[0]->nombre_tramite); ?>

# Ciudad
 <?php echo e($ad[0]->ciudad); ?>

# Valor trámite
 $ <?php echo e(number_format($ad[0]->valor_tramite,0,'.','.')); ?>

# Descripción del anuncio
 <?php echo e($ad[0]->descripcion_anuncio); ?>


Estado: ACTIVO

## BALANCE DE RECARGA ##
$ <?php echo e(number_format($recarga,0,'.','.')); ?> 

#[Recarga][1]
[1]:<?php echo e($url); ?>#

  No dejes agotar tu recarga, para que puedan seguir viendo tu anuncio.


Gracias, por seguir confiando en nosotros<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
