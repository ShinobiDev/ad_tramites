<div>
	<div id="div_comentarios_<?php echo e($ad->id); ?>" class="comentarios">
		<?php $__currentLoopData = $ad->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<h5><b><?php echo e($c->opinion); ?></b></h5>
			<h6>Hecho por: <?php echo e($c->nombre); ?></h6>
			<h6>El día: <?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $c->updated_at)->format('M d, Y h:i A')); ?></h6>
	 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	    
	</div>
	<div id="espera_<?php echo e($ad->id); ?>"></div>
    <button type="button" class="btn btn-default"  onclick="ver_mas_comentarios('<?php echo e($ad->id); ?>')">VER MÁS COMENTARIOS</button>
</div>
<script type="text/javascript">
	var limit_min=0;
	var limit_maxs=5;
	function  ver_mas_comentarios(id){
		limit_min+=5;
		
		mostrar_cargando('espera',200,'Un momento, por favor...');

		peticion_ajax("GET","admin/ver_mas_comentarios/"+id+"/"+limit_min+"/"+limit_maxs,{},function(rs){
			
			if(rs.respuesta){

				mostrar_mas_comentarios(rs.datos);
				$('#espera_'+id).html("");
			}else{
				$('#espera_'+id).html("No existen más comentarios");				
			}
		});
	}
	function mostrar_mas_comentarios(datos){
		var div=document.getElementById("div_comentarios");
		for(var d in datos){
			var h5_opinion=document.createElement("h5");
			var b_opinion=document.createElement("b");
			b_opinion.innerHTML=datos[d].opinion;
			h5_opinion.appendChild(b_opinion);
			div.appendChild(h5_opinion);
			var h6_name=document.createElement("h6");
			h6_name.innerHTML="Hecho por: "+datos[d].nombre;
			div.appendChild(h6_name);
			var h6_dia=document.createElement("h6");
			h6_dia.innerHTML="El día: "+datos[d].updated_at;
			div.appendChild(h6_dia);
		}		

	}

</script>