<table id="users-table" class="table table-striped table-codensed table-hover table-resposive">
      <thead>
        <tr>
          <th class="text-center">Trámite</th>
          <th class="text-center">Descripción</th>
          <th class="text-center">Ciudad</th>
          <th class="text-center" style="width:25%">Valor</th>
          <th class="text-center">Calificación</th>
          <th class="text-center">Acciones</th>
        </tr>
      </thead>
      <tbody id="tbbody">
        
        <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <tr>
            <td class="text-green text-center"><strong><h4> <?php echo e($ad->nombre_tramite); ?></h4></strong></td>

            <td class="text-center" style="width:30%"><strong><h5><?php echo e($ad->descripcion); ?></h5></strong></td>

            <td class="text-center"><strong><h5><?php echo e($ad->ciudad); ?></h5></strong></td>

            <td class="text-center" style="width:25% padding: 0px">

              <strong style="margin: 0px;padding: 0px"><h5 style="margin: 0px;padding: 0px">$ <?php echo e(number_format($ad->valor_tramite,0,',','.')); ?></h5></strong>

            </td>

            <td style="width:10%">
              <?php echo $__env->make('partials.stars', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>

              <?php if(auth()->guard()->guest()): ?>
                     <!--AQUI SE MUESTRA LOS BOTONES PARA LOGIN -->

                      <button id="<?php echo e('btn_'.$ad->cod_anuncio); ?>" type="button" class="btn btn-success" data-toggle="modal" onclick="descontar_recargar('<?php echo e('ventana_login'.$ad->id); ?>','<?php echo e($ad->id); ?>','0','info')">
                        Ver info
                        </button>

                      <button id="<?php echo e('btn_'.$ad->cod_anuncio); ?>" type="button" class="btn btn-default" data-toggle="modal" onclick="descontar_recargar('<?php echo e('ventana_login'.$ad->id); ?>','<?php echo e($ad->id); ?>','0','venta')">
                        Comprar
                      </button>

                      <?php echo $__env->make('anuncios.ventana_modal_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      


              <?php else: ?>



                    <?php if($ad->btn_info): ?>
                      <?php if($ad->visto!=""): ?>

                       <!--<a href="admin/anuncios_vistos" class="btn btn-primary">Ya lo Viste</a>-->
                        <button id="<?php echo e('btn_'.$ad->id); ?>" type="button" class="btn btn-primary" data-toggle="modal" onclick="descontar_recargar('<?php echo e('infogen'.$ad->id); ?>','<?php echo e($ad->id); ?>','0','info')">
                        Ya lo Viste
                        </button>
                         <?php echo $__env->make('anuncios.ventana_modal_info_general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      <?php else: ?>
                        <button id="<?php echo e('btn_'.$ad->id); ?>" type="button" class="btn btn-success" data-toggle="modal" onclick="descontar_recargar('<?php echo e('infogen'.$ad->id); ?>','<?php echo e($ad->id); ?>','<?php echo e($ad->costo_clic); ?>','info')">
                        Ver info
                        </button>
                        <a id="an_<?php echo e($ad->id); ?>" href="admin/anuncios_vistos" class="btn btn-primary" style="display: none">Ya lo Viste</a>
                        <?php echo $__env->make('anuncios.ventana_modal_info_general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                      <?php endif; ?>

                    <?php endif; ?>

                    <?php if($ad->btn_payu): ?>
                      <button id="<?php echo e('btn_'.$ad->id); ?>" type="button" class="btn btn-default" data-toggle="modal" onclick="descontar_recargar('<?php echo e('infoventa'.$ad->id); ?>','<?php echo e($ad->id); ?>','0','compra')" >
                        Comprar
                      </button>

                     <?php echo $__env->make('anuncios.ventana_modal_info_anuncio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>



              <?php endif; ?>


            </td>
           </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
</table>
