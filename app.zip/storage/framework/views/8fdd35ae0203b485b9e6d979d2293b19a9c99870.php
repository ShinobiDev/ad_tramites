 <div class="modal fade" id="descargar_documentos<?php echo e($ad->id_pago); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="overflow:scroll">
    <div class="modal-dialog" role="document">
      <div class="modal-content">

        <div class="modal-header bg-primary">
          <h5 class="modal-title text-center" id="exampleModalLabel">Descarga los archivos adjuntos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="salir_modal('descargar_documentos<?php echo e($ad->id_pago); ?>')">
            <span aria-hidden="true" >&times;</span>
          </button>
        </div>

        <div class="modal-body">
            
            <div class="form-horizontal">
                <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    
                    <div class="col-md-6 col-md-offset-4" >
                      <?php $__empty_1 = true; $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <?php if(property_exists($ar,'url_documento')): ?>
                        <a href="<?php echo e($ar->url_documento); ?>">Descargar</a>                        
                      <?php endif; ?>  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        vacio
                      <?php endif; ?>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="salir_modal('descargar_documentos<?php echo e($ad->id_pago); ?>')">SALIR</button>
        </div>
      </div>
    </div>
 }
</div>


