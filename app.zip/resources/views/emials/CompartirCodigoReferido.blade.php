@component('mail::message')


![logo](http://tutramitador.com/core/img/logolarge.png)

Hola

Te sugiero este sitio web donde se pueden encontrar tramitadores de tránsito de todo en todo el país, para traspasos, fotomultas,  inscripciones y levantamientos de prenda entre otros trámites. 

Yo ya estoy registrado y te sugiero registrarte, el registro es totalmente gratuito.


#[Puedes registrarte aquí][1]
[1]:{{$url}}  

Cordialmente, 

{{$user->nombre}}

@endcomponent



