@component('mail::message')


![logo](http://tutramitador.com/core/img/logo.png)


#Solo te falta un paso, para cambiar tu correo electrónico de contacto#
#para ello debes simplemente presionar el link, que esta adjunto y finalizaras el proceso.#


#[Cambiar Correo][1]
[1]:{{$url}}


Gracias,<br>
{{ config('app.name') }}
@endcomponent
