<script src="{{$key[0]->key}}"
        async defer></script>
<script src="{{asset('js/placesapi.js')}}"></script>
