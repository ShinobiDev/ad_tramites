<center>
    <a href="http://prismaweb.co/paginas-web/" target="_blank" >Implementado por: </a>
    <a href="http://prismaweb.co/paginas-web/" target="_blank" ><img style="background-color: black" src="http://www.prismaweb.net/img/prismaweb-footer-webs.png" alt="WWW.PRISMAWEB.CO - Skype: prismaweb22" /></a>
<center/>