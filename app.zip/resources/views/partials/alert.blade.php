<div id="div_Success" style="display: none" class="alert alert-success">
		<h3>
			<i class="fa fa-info-circle"></i>
			<strong id="stMensajeSuccess"></strong>
		</h3>
</div>
<div id="div_Alert" style="display: none" class="alert alert-danger">
		<h3 class="text-center">
			<i class="fa fa-info-circle"></i>
			<strong id="stMensajeAlert"></strong>
		</h3>
</div>
