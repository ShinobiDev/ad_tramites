 <div class="modal fade" id="ventana_enviar_documentos" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="overflow:scroll">
    <div class="modal-dialog" role="document">
      <div class="modal-content">

        <div class="modal-header bg-primary">
          <h5 class="modal-title text-center" id="exampleModalLabel">Adjunta los documentos necesarios</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="salir_modal('ventana_enviar_documentos')">
            <span aria-hidden="true" >&times;</span>
          </button>
        </div>

        <div class="modal-body">
            
            <div class="form-horizontal">

               

                
                <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
                    <label for="password" class="col-md-4 control-label">Documentos </label>
                    <div class="col-md-6 col-md-offset-4" >
                      <form action="{{route('subir_archivos')}}" class="dropzone" method="POST">
                           {{csrf_field()}}  
                           <input type="hidden" name="id_anuncio" id="hd_id_anuncio" >
                            <input type="hidden" name="id_user_compra" id="hd_id_user_venta" >
                            <input type="hidden" name="id_pago" id="hd_id_pago">
                          <div class="fallback">
                            
                            <input name="file" type="file" multiple />
                          </div>
                      </form>
    
                    </div>
                </div>

            
                <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
                    <label for="password" class="col-md-4 control-label">Información adicional </label>
                    <div class="col-md-6 col-md-offset-4" >
                      <form class="form-horizontal" method="POST" action="{{ route('notificar_envio_documentos') }}">
                           {{csrf_field()}}  
                           <input type="hidden" name="id_pago" id="hd_id_pago_2">
                           <input type="hidden" name="id_anuncio" id="hd_id_anuncio_2" >
                            <input type="hidden" name="id_user_compra" id="hd_id_user_venta_2" >
                           <textarea name="mensaje" class="form-control" rows="8" cols="200"></textarea>
                          <button type="submit" class="btn btn-primary">
                                Enviar a tu tramitador
                          </button>
                      </form>
    
                    </div>
                </div>
            </div>
            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="salir_modal('ventana_enviar_documentos')">SALIR</button>
        </div>
      </div>
    </div>
</div>

<script type="text/javascript">
        
    var dz=new Dropzone('.dropzone',{
        url:"/prueba",
        //url:"{{config('app.url')}}"+"/subir_archivo",
        dictDefaultMessage:"Sube tus archivos aquí",
        maxFiles:10,
        maxFilesize:10,//MB
        acceptedFiles: "image/*,.psd,.pdf",
        dictMaxFilesExceeded:"Solo esta permitido subir 10 archivos",
        dictInvalidFileType:"Este tipo de archivos no esta permitido",
        headers:{
          'X-CSRF-TOKEN':'{{csrf_token()}}'
        }    

    });
    dz.on('error',function(file,rs){
        console.log(rs.errors.file[0]);
        var msg=rs.errors.file[0];

        document.querySelector(".dz-error-message > span").innerHTML=msg; 
    });
    //Dropzone.autoDiscover=false;   
  
</script>      
