@extends('layouts.app')
@section('content')

      <section class="pages container">
          <div class="page page-about">
                <h1 class="text-capitalize text-center">Pagína no Encontrada</h1> <hr>
                <p class="text-center">Volver a <a href="{{route('home')}}">Inicio</a></p>
          </div>
      </section>

@endsection
