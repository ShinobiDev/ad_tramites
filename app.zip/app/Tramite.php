<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Tramite extends Model
{
    //
    /*public function truncar_detalle(){
    	DB::table('detalle_anuncios_tramites')->truncate();
    }*/
    
}
