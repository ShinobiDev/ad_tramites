<?php

namespace App\Policies;

use App\User;
use Spatie\Permission\Models\Role;
use Illuminate\Auth\Access\HandlesAuthorization;

class RolePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view the Role.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function view(User $user, Role $role)
    {
        //
        return $user->hasRole('Admin') || $user->hasPermissionTo('Ver Roles');
    }

    /**
     * Determine whether the user can create Roles.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->hasRole('Admin') || $user->hasPermissionTo('Crear Roles');
    }

    /**
     * Determine whether the user can update the Role.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $role
     * @return mixed
     */
    public function update(User $user, Role $role)
    {
        //
        return $user->hasRole('Admin') || $user->hasPermissionTo('Editar Roles');
    }

    /**
     * Determine whether the user can delete the Role.
     *
     * @param  \App\User  $user
     * @param  \App\Role  $Role
     * @return mixed
     */
    public function delete(User $user, Role $role)
    {
        //
        if ($role->id === 1) {

            $this->deny('No se puede eliminar este rol');

      }
      return $user->hasRole('Admin') || $user->hasPermissionTo('Eliminar Roles');
    }
}
